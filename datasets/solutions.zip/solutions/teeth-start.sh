cut -d , -f 2 ____ | grep -v Tooth | sort | uniq ____
