wc -l $@ | grep -v total
