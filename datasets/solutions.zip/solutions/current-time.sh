# Print the date and time at one-second intervals until stopped.
while true
do
    date
    sleep 1
done
