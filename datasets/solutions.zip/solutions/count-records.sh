tail -q -n +2 $@ | wc -l
