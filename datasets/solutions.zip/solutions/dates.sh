cut -d , -f 1 seasonal/*.csv
