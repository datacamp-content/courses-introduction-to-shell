head -n ____ ____ | tail -n ____
