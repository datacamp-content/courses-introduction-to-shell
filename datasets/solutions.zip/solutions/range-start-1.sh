wc -l ____ | grep ____ Total
