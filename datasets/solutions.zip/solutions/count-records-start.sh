tail -q -n +2 ____ | wc ____
