wc -l $@ | grep -v total | sort -n | head -n 1
